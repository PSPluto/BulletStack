using UnityEngine;

public class StateManager : MonoBehaviour
{
    // �C�x���g���`
    public static System.Action<int> OnStateChanged;
    public static int CurrentState { get; private set; }

    public static void ChangeState(int newState)
    {
        CurrentState = newState;
        OnStateChanged?.Invoke(newState);
        Debug.Log($"State��{newState}�ɂȂ�܂���");
    }
    private void OnDestroy()
    {
        OnStateChanged = null;
    }
}
