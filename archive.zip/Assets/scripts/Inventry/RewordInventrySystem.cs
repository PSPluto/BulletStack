using UnityEngine;

public class RewordInventrySystem : MonoBehaviour
{
    public Modifier[] rewardInventory = new Modifier[3];

    public PlayerInventory pInventry;


    public void NewRewardCreate()
    {
        CleanTable();
        for (int i = 0; i < 3; i++)
        {
            rewardInventory[i] = ModifierGenerator.Instance.GenerateRandomModifier();
        }

        Debug.Log("�����[�h��3�g���X�V���܂����I");
    }

    public void ClaimReward(int index)
    {
        pInventry.playerInventry.Add(rewardInventory[index]);
        rewardInventory[index] = null;
        CleanTable();
    }

    public void CleanTable()
    {
        for (int i = 0; i < rewardInventory.Length; i++)
        {
            if (rewardInventory[i] != null) Destroy(rewardInventory[i]);
        }

    }
}