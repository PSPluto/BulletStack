using UnityEngine;

public abstract class Modifier : ScriptableObject
{
    [Header("�����ڂ̐ݒ�")]
    public string chipName;
    [TextArea]
    public string description;
    public Sprite icon;
    public Color Color = Color.white;
    [Header("���ʂ̐ݒ�")]
    public float resistance = 0.5f;
    public float voltageCost = 2f;

    public abstract void Process(Signal signal);
}
